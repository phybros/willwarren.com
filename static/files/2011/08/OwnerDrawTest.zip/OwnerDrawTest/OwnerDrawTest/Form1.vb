﻿Public Class Form1

    ' Downloaded from WillWarren.com

    Private Sub myTreeView_DrawNode(sender As System.Object, e As System.Windows.Forms.DrawTreeNodeEventArgs) Handles myTreeView.DrawNode
        ' The DrawMode property on the parent TreeView must 
        ' be set to OwnerDrawText for this event to fire
        e.DrawDefault = True
        TextRenderer.DrawText(e.Graphics, e.Node.Name, e.Node.NodeFont, New Point(e.Node.Bounds.Right + 2, e.Node.Bounds.Top), SystemColors.GrayText, SystemColors.Window)
    End Sub

    Private Sub btnAddNode_Click(sender As System.Object, e As System.EventArgs) Handles btnAddNode.Click
        'Create a new node
        Dim NewNode As New TreeNode()

        'Set the node properties
        NewNode.Text = txtText.Text
        NewNode.Name = txtName.Text

        'Add the node to the TreeView
        myTreeView.Nodes.Add(NewNode)
    End Sub

End Class

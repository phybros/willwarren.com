﻿Imports System.Threading

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        DoSomething(NumericUpDown1.Value * 1000)
    End Sub

    Private Sub DoSomething(ByVal LengthInMilliseconds As Integer)
        Thread.Sleep(LengthInMilliseconds)
        Console.WriteLine("***** Work Complete *****")
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        DoSomethingAsync(NumericUpDown1.Value * 1000)
    End Sub

    Private Sub DoSomethingAsync(ByVal LengthInMilliseconds As Integer)
        ThreadPool.QueueUserWorkItem(AddressOf DoSomething, LengthInMilliseconds)
    End Sub

End Class
